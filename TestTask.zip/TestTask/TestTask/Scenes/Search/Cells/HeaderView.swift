//
//  HeaderView.swift
//  TestTask
//
//  Created by Sourabh Jaiswal on 01/10/21.
//  Copyright © 2021 Saurabh Jaiswal. All rights reserved.
//

import UIKit

class HeaderView: UITableViewHeaderFooterView {

   @IBOutlet weak var lblUnitName: UILabel!

}
