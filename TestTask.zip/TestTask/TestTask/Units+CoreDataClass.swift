//
//  Units+CoreDataClass.swift
//  
//
//  Created by Sourabh Jaiswal on 01/10/21.
//
//

import Foundation
import CoreData

@objc(Units)
public class Units: NSManagedObject {

}
